﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace plantilla
{
    public partial class prueba : System.Web.UI.Page
    {
        private MatriculaDataContext matricula = new MatriculaDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnIngresarLogVendedor_Click(object sender, EventArgs e)
        {
                string usuario = UserEmail.Text;
                string contrasena = UserPass.Text;
           
            var resultado = from C in matricula.spLogin(usuario, contrasena)
                            select C;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var x in resultado)
            {
                codError = Convert.ToByte(x.CodError);
                mensaje = x.Mensaje;
            }
            if (codError == 0)
            {
                Response.Write("<script>alert('Contraseña correcta'); location.href = 'https://localhost:44327/home.aspx';</script");
            }else
            {
                Response.Write("<script>alert('Contraseña o correo incorrecto, intente de nuevo');</script");
            }
        }
    }
}