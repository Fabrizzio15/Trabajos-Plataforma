﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class Inicio : System.Web.UI.Page
    {
        private MatriculadosDataContext matriculados = new MatriculadosDataContext();

        private void NumeroMatriculasTotal()
        {            
            var resultado = from M in matriculados.spNumeroMatriculasTotal() select M;
            byte NumeroMatriculas = 0;            
            foreach (var X in resultado)
            {
                NumeroMatriculas = Convert.ToByte(X.NumeroMatriculas);                
            }
            lTotal.Text = NumeroMatriculas.ToString();
        }

        private void NumeroMatriculasPendientes()
        {
            var resultado = from M in matriculados.spNumeroMatriculasPendientes() select M;
            byte NumeroMatriculas = 0;
            foreach (var X in resultado)
            {
                NumeroMatriculas = Convert.ToByte(X.NumeroMatriculas);
            }
            lPendientes.Text = NumeroMatriculas.ToString();
        }

        private void NumeroMatriculasDesaprobadas()
        {
            var resultado = from M in matriculados.spNumeroMatriculasDesaprobadas() select M;
            byte NumeroMatriculas = 0;
            foreach (var X in resultado)
            {
                NumeroMatriculas = Convert.ToByte(X.NumeroMatriculas);
            }
            lDesaprobados.Text = NumeroMatriculas.ToString();
        }

        private void NumeroMatriculasObservados()
        {
            var resultado = from M in matriculados.spNumeroMatriculasObservados() select M;
            byte NumeroMatriculas = 0;
            foreach (var X in resultado)
            {
                NumeroMatriculas = Convert.ToByte(X.NumeroMatriculas);
            }
            lObservados.Text = NumeroMatriculas.ToString();
        }

        private void NumeroMatriculasAprobados()
        {
            var resultado = from M in matriculados.spNumeroMatriculasAprobados() select M;
            byte NumeroMatriculas = 0;
            foreach (var X in resultado)
            {
                NumeroMatriculas = Convert.ToByte(X.NumeroMatriculas);
            }
            lAprobados.Text = NumeroMatriculas.ToString();
        }

        private void CargarNumeroEstadosMatriculas()
        {
            NumeroMatriculasTotal();
            NumeroMatriculasPendientes();
            NumeroMatriculasDesaprobadas();
            NumeroMatriculasObservados();
            NumeroMatriculasAprobados();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gvReservas.DataSource = matriculados.spListarReservasPendientes();
                gvReservas.DataBind();
                CargarNumeroEstadosMatriculas();
            }            
        }

        protected void lbPendientes_Click(object sender, EventArgs e)
        {
            gvReservas.DataSource = matriculados.spListarReservasPendientes();
            gvReservas.DataBind();
        }

        protected void lbDesaprobados_Click(object sender, EventArgs e)
        {
            gvReservas.DataSource = matriculados.spListarReservasDesaprobadas();
            gvReservas.DataBind();
        }

        protected void lbObservados_Click(object sender, EventArgs e)
        {
            gvReservas.DataSource = matriculados.spListarReservasObservados();
            gvReservas.DataBind();
        }

        protected void lbAprobados_Click(object sender, EventArgs e)
        {
            gvReservas.DataSource = matriculados.spListarReservasAprobadas();
            gvReservas.DataBind();
        }

        protected void btnActualizarEstadoMatricula_Click(object sender, EventArgs e)
        {
            string CodMatricula = txtCodMatricula.Text.Trim();
            string EstadoMatricula = ddlEstadoMatricula.Text.Trim();
            
            var resultado = from M in matriculados.spCambiarEstadoMatricula(CodMatricula, EstadoMatricula) select M;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvReservas.DataSource = matriculados.spListarReservasPendientes();
                gvReservas.DataBind();
            }
            CargarNumeroEstadosMatriculas();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void lbTodos_Click(object sender, EventArgs e)
        {
            gvReservas.DataSource = matriculados.spListarTodasReservas();
            gvReservas.DataBind();
        }
       


        private void DescargarRutaLibretasNotas(string ruta)
        {
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + ruta + "");
            Response.TransmitFile(Server.MapPath("~/ArchivosSubidos/" + ruta + ""));
            Response.End();
        }

        protected void gvreservasaction(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewDetails")
            {
                int rowno = Int32.Parse(e.CommandArgument.ToString());
                string ruta = gvReservas.Rows[rowno].Cells[10].Text.ToString();                
                DescargarRutaLibretasNotas(ruta);                
            }
        }
    }
}