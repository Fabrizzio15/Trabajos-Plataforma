﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class Estudiantes : System.Web.UI.Page
    {
        private MatriculadosDataContext matriculados = new MatriculadosDataContext();

        private void ListarEstudiantes()
        {
            gvEstudiantes.DataSource = matriculados.spListarEstudiantes();
            gvEstudiantes.DataBind();
        }

        private void LimpiarCampos()
        {
            txtdniestudiante.Text = "";
            txtnombres.Text = "";
            txtapellidos.Text = "";
            txtnumerodetelefono.Text = "";
            txtfecnacimiento.Text = "";
            txtnombreapoderado.Text = "";
            txtdniapoderado.Text = "";
            txtcorreo.Text = "";
            txtcontrasena.Text = "";

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListarEstudiantes();
            }
        }

        protected void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;
            string nombres = txtnombres.Text;
            string apellidos = txtapellidos.Text;
            string numerotelefono = txtnumerodetelefono.Text;
            string fechanacimiento = txtfecnacimiento.Text;
            string nombreapoderado = txtnombreapoderado.Text;
            string dniapoderado = txtdniapoderado.Text;
            string rutalibreta = txtrutalibretanotas.HasFile.ToString();
            string correo = txtcorreo.Text;
            string contrasena = txtcontrasena.Text;
            string nivel = ddlNivelEducacion.SelectedValue.Trim();
            string grado = ddlGrado.SelectedValue.Trim();
            string secc = ddlSeccion.SelectedValue.Trim();
            var resultado = from S in matriculados.spAgregarEstudiante(dni, nombres, apellidos, fechanacimiento, numerotelefono, nombreapoderado, dniapoderado, rutalibreta, correo, contrasena, nivel, grado, secc)
                            select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvEstudiantes.DataSource = matriculados.spListarEstudiantes();
                gvEstudiantes.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnActualizarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;
            string nombres = txtnombres.Text;
            string apellidos = txtapellidos.Text;
            string numerotelefono = txtnumerodetelefono.Text;
            string fechanacimiento = txtfecnacimiento.Text;
            string nombreapoderado = txtnombreapoderado.Text;
            string dniapoderado = txtdniapoderado.Text;
            string rutalibreta = txtrutalibretanotas.HasFile.ToString();
            string correo = txtcorreo.Text;
            string contrasena = txtcontrasena.Text;

            var resultado = from S in matriculados.spModificarEstudiante(dni, nombres, apellidos, fechanacimiento, numerotelefono, nombreapoderado, dniapoderado, rutalibreta, correo)
                            select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvEstudiantes.DataSource = matriculados.spListarEstudiantes();
                gvEstudiantes.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;

            var resultado = from S in matriculados.spEliminarEstudiante(dni) select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvEstudiantes.DataSource = matriculados.spListarEstudiantes();
                gvEstudiantes.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnListarCliente_Click(object sender, EventArgs e)
        {
            ListarEstudiantes();
        }

        protected void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            string criterio = ddlBuscarEstudiante.Text;
            string text = txtBuscarSeccion.Text;

            buscarE(criterio, text);

        }
        public void buscarE(string c, string t)
        {
            gvEstudiantes.DataSource = matriculados.spBuscarEstudiante(c, t);
            gvEstudiantes.DataBind();
        }
    }
}