﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private MatriculadosDataContext matricula = new MatriculadosDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
         
        }

        protected void btnIngresarLogVendedor_Click(object sender, EventArgs e)
        {
            string usuario = txtusuario.Text.Trim();
            string contrasena = txtcontrasena.Text.Trim();
            var resultado = from C in matricula.spLoginUsuarioE(usuario, contrasena)
                            select C;
            byte codError = 0;
            string mensaje = string.Empty;
            string correo = string.Empty;

            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
                correo = X.Correo;
            }
            if (codError == 0)
            {
                if (mensaje == "ADMINISTRATIVO")
                {
                    Response.Write("<script>alert('Correcto, Se ingreso como Administrador');</script");
                    //FormsAuthentication.RedirectFromLoginPage(correo, false);
                    Session["correo"] = correo;
                    Response.Redirect("Inicio.aspx");
                }
                if (mensaje == "ESTUDIANTE")
                {
                    Response.Write("<script>alert('Correcto, Se ingreso como Estudiante');</script");
                    Session["correo"] = correo;
                    Response.Redirect("EstudiantePerfil.aspx");
                }
            }
            else 
            {
                Response.Write("<script>alert('" + mensaje + "');</script");
            }            
        }

        protected void LBreservar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ReservarMatricula.aspx");
        }
    }
}