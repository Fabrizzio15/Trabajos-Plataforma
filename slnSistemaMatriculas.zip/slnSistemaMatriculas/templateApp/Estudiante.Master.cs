﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class Estudiante1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["correo"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                lUsuario1.Text = Session["correo"].ToString();
                lUsuario2.Text = Session["correo"].ToString();
                lUsuario3.Text = Session["correo"].ToString();
            }
        }

        protected void lbCerrarSesion_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
    }
}