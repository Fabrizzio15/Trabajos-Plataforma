﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class Administradores : System.Web.UI.Page
    {
    
        private MatriculadosDataContext matriculados = new MatriculadosDataContext();

        private void ListarAdministrativo()
        {
            gvAdministradores.DataSource = matriculados.spListarAdministrativos();
            gvAdministradores.DataBind();
        }

        private void LimpiarCampos()
        {
            txtdniestudiante.Text = "";
            txtnombres.Text = "";
            txtapellidos.Text = "";
            txtnumerodetelefono.Text = "";
            
            txtcorreo.Text = "";
            txtcontrasena.Text = "";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListarAdministrativo();
            }
        }

        protected void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;
            string nombres = txtnombres.Text;
            string apellidos = txtapellidos.Text;
            string numerotelefono = txtnumerodetelefono.Text;
            string cargo = ddlcargo.SelectedValue.ToString();

            string correo = txtcorreo.Text;
            string contrasena = txtcontrasena.Text;
            var resultado = from S in matriculados.spAgregarAdministrativo(dni, nombres, apellidos, numerotelefono, cargo, correo, contrasena)
                            select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvAdministradores.DataSource = matriculados.spListarAdministrativos();
                gvAdministradores.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnActualizarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;
            string nombres = txtnombres.Text;
            string apellidos = txtapellidos.Text;
            string numerotelefono = txtnumerodetelefono.Text;
            string cargo = ddlcargo.SelectedValue.ToString();

            string correo = txtcorreo.Text;
            
            var resultado = from S in matriculados.spModificarAdministrativo(dni, nombres, apellidos, numerotelefono, cargo, correo)
                            select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvAdministradores.DataSource = matriculados.spListarAdministrativos();
                gvAdministradores.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;

            var resultado = from S in matriculados.spEliminarAdministrativo(dni) select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvAdministradores.DataSource = matriculados.spListarAdministrativos();
                gvAdministradores.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }

        protected void btnListarCliente_Click(object sender, EventArgs e)
        {
            ListarAdministrativo();
        }

        protected void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            string criterio = ddlBuscarEstudiante.Text;
            string text = txtBuscarSeccion.Text;

            buscarE(criterio, text);

        }
        public void buscarE(string c, string t)
        {
            gvAdministradores.DataSource = matriculados.spBuscarAdministrativos(c, t);
            gvAdministradores.DataBind();
        }
    }
    
}