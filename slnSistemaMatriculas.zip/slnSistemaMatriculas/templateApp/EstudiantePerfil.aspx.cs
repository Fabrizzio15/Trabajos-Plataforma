﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace templateApp
{
    public partial class EstudiantePerfil : System.Web.UI.Page
    {
        private MatriculadosDataContext matriculados = new MatriculadosDataContext();
        protected void btnEstadoMatricula_Click(object sender, EventArgs e)
        {
            gvDatosEstudiantes.DataSource = matriculados.spEstudianteporMatricula("bustinza@gmail.com");
            gvDatosEstudiantes.DataBind();
        }

        protected void btnDatosEstudiante_Click(object sender, EventArgs e)
        {
            gvDatosEstudiantes.DataSource = matriculados.spEstudianteporCorreo("bustinza@gmail.com");
            gvDatosEstudiantes.DataBind();
        }


        private void ListarEstudiantes()
        {
            gvDatosEstudiantes.DataSource = matriculados.spEstudianteporMatricula("bustinza@gmail.com");
            gvDatosEstudiantes.DataBind();
        }

        private void LimpiarCampos()
        {
            txtdniestudiante.Text = "";
            txtnombres.Text = "";
            txtapellidos.Text = "";
            txtnumerodetelefono.Text = "";
            txtfecnacimiento.Text = "";
            txtnombreapoderado.Text = "";
            txtdniapoderado.Text = "";
            txtcorreo.Text = "";
            txtcontrasena.Text = "";

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListarEstudiantes();
            }
        }

        protected void btnActualizarCliente_Click(object sender, EventArgs e)
        {
            string dni = txtdniestudiante.Text;
            string nombres = txtnombres.Text;
            string apellidos = txtapellidos.Text;
            string numerotelefono = txtnumerodetelefono.Text;
            string fechanacimiento = txtfecnacimiento.Text;
            string nombreapoderado = txtnombreapoderado.Text;
            string dniapoderado = txtdniapoderado.Text;
            string rutalibreta = txtrutalibretanotas.HasFile.ToString();
            string correo = txtcorreo.Text;
            string contrasena = txtcontrasena.Text;

            HttpPostedFile file = txtrutalibretanotas.PostedFile;
            if (file == null) return;

            string archivo = (txtdniestudiante.Text + " - " + file.FileName).ToLower();

            file.SaveAs(Server.MapPath("~/ArchivosSubidos/" + archivo));

            var resultado = from S in matriculados.spModificarEstudiante(dni, nombres, apellidos, fechanacimiento, numerotelefono, nombreapoderado, dniapoderado, archivo, correo)
                            select S;
            byte codError = 0;
            string mensaje = string.Empty;
            foreach (var X in resultado)
            {
                codError = Convert.ToByte(X.CodError);
                mensaje = X.Mensaje;
            }
            if (codError == 0)
            {
                gvDatosEstudiantes.DataSource = matriculados.spEstudianteporCorreo("bustinza@gmail.com");
                gvDatosEstudiantes.DataBind();
            }
            LimpiarCampos();
            Response.Write("<script>alert('" + mensaje + "');</script");
        }
    }
}